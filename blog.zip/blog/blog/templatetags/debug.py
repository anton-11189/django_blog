from django import template

register = template.Library()

@register.filter
def as_dict(value):
    """Преобразует объект в словарь"""
    return value.__dict__